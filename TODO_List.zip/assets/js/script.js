let designl = ['Work','Personal','Cleaning','Others'] //creating class for implementing design to different category 
$(document).ready(function(){

    let category = document.getElementsByClassName('category'); // getting all the class name category 
        for(let i=0;i<category.length;i++){ // looping in the  categorys to find the which categry class belongs and implement according sesign check home.css to get the color of eact section
            if(category[i].innerHTML.trim()=='Work'){ 
               category[i].classList.add(designl[0])
               category[i].classList.add('commonClass')
            }
            else if(category[i].innerHTML.trim()=='Personal'){
                category[i].classList.add(designl[1])
                category[i].classList.add('commonClass')
            }else if(category[i].innerHTML.trim()=='Cleaning'){
                category[i].classList.add(designl[2])
                category[i].classList.add('commonClass')
            }else if(category[i].innerHTML.trim()=='Others'){
                category[i].classList.add(designl[3])
                category[i].classList.add('commonClass')
            }
        }
});

// this in responsible for making  making cross line when the idem is  checked for deleting
function checkedOrNot(){ 
    let cb = document.querySelectorAll('.delete-check'); // getting all the check-box class 
    let description_define = document.querySelectorAll('.description_define'); // getting all the class where descripting of TODO is defined
    let dueDateSelector = document.querySelectorAll('.dueDate'); // getting all the class for dueDate
    for(let i=0;i<description_define.length;i++){
        let dueDate = dueDateSelector[i].innerHTML;
        // checking if checkbox is checked  if checked a line will pass through the text(-) else if it is unchecked no line will pass through date and description
            if(cb[i].checked == true){ 
            document.getElementById(cb[i].getAttribute('uid')).style.textDecoration = 'line-through'
            document.getElementById(cb[i].getAttribute('uid')+dueDate).style.textDecoration  = 'line-through'
            }
            else if(cb[i].checked == false){
            document.getElementById(cb[i].getAttribute('uid')).style.textDecoration = 'none'
            document.getElementById(cb[i].getAttribute('uid')+dueDate).style.textDecoration  = 'none'
        }
       
    } 
   
}

// this addEventListener  come into action when we clicked on delete button after we checked which list of items need to be deleted
document.getElementById('deleteButton').addEventListener('click',function(){
    let checedvaluew = document.querySelectorAll('.delete-check:checked') // getting only checked vale
    let arrcheck = []  // creating the lsit of checked array
    for(let i of checedvaluew){
        let gg=''
       gg= i.getAttribute('uid')    // getting uniue id from and pushing into array
        console.log(gg)
        arrcheck.push(gg);
    }
    if(arrcheck.length===0){ // checking if array is null the 
        console.log('no item is checked')
        swal("No item is checked!!", "please select item to remove!", "error"); // using show alert to show if there is no items in the array
        return;
    }
    //here we are making delete request with the help of Ajax request 
    $.ajax({
        type: 'post',
        url: '/delete_todo/?id='+arrcheck,
        success: function(){ // on ajax sunnces i.e when data is delete


            swal(" TODO Item is Deleted Successfully", "Click ok to go back to Home ", "success") // using sweet alert to show the data is delete
            .then(redir => {
                window.location = '/';
            })
           
        },
        error: function(err){ 
            console.log(err);
        }

    });
})